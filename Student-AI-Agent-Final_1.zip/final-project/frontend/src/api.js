// ═══════════════════════════════════════════════════════════════
//
//   API CONFIGURATION FILE
//
//   This is the ONLY frontend file you need to edit.
//
//   TO CONNECT TO YOUR REAL SQL SERVER:
//     1. Make sure your backend is running (cd backend → npm run dev)
//     2. Scroll to the VERY BOTTOM of this file
//     3. Change:  export default MOCK_API
//        To:      export default LIVE_API
//     4. Save. Done. The agent now uses your real database.
//
// ═══════════════════════════════════════════════════════════════

// ╔═══════════════════════════════════════════════════════════════╗
// ║                                                               ║
// ║   👇👇👇  YOUR BACKEND SERVER URL  👇👇👇                   ║
// ║                                                               ║
// ║   Change this if your backend runs on a different machine.    ║
// ║   If backend is on the same computer, leave as localhost.     ║
// ║                                                               ║
// ╚═══════════════════════════════════════════════════════════════╝

const API_BASE = "http://localhost:5000";

// ─── MOCK API (demo data, no server needed) ──────────────────────

const wait = (ms) => new Promise((r) => setTimeout(r, ms));

const MOCK_DB = {
  colleges: [
    { college_id: 1, name: "delhi technical university", display: "Delhi Technical University" },
    { college_id: 2, name: "mumbai institute of technology", display: "Mumbai Institute of Technology" },
    { college_id: 3, name: "bangalore engineering college", display: "Bangalore Engineering College" },
  ],
  students: [
    { id: 1, roll: "DTU2024001", name: "aarav sharma", display: "Aarav Sharma", cid: 1, course: "B.Tech CSE", semester: "Sem IV", reg: true },
    { id: 2, roll: "DTU2024002", name: "priya patel", display: "Priya Patel", cid: 1, course: "B.Tech ECE", semester: "Sem IV", reg: true },
    { id: 3, roll: "DTU2024003", name: "rohan gupta", display: "Rohan Gupta", cid: 1, course: "B.Tech ME", semester: "Sem IV", reg: true },
    { id: 4, roll: "MIT2024001", name: "sneha reddy", display: "Sneha Reddy", cid: 2, course: "B.Tech CSE", semester: "Sem IV", reg: true },
    { id: 5, roll: "MIT2024002", name: "arjun singh", display: "Arjun Singh", cid: 2, course: "B.Tech IT", semester: "Sem IV", reg: false },
    { id: 6, roll: "BEC2024001", name: "kavya nair", display: "Kavya Nair", cid: 3, course: "B.Tech CSE", semester: "Sem IV", reg: true },
  ],
  results: {
    1: [
      { name: "Data Structures & Algorithms", marks: 85, max: 100, grade: "A" },
      { name: "Operating Systems", marks: 78, max: 100, grade: "B+" },
      { name: "Database Management Systems", marks: 92, max: 100, grade: "A+" },
      { name: "Computer Networks", marks: 88, max: 100, grade: "A" },
      { name: "Software Engineering", marks: 74, max: 100, grade: "B+" },
    ],
    2: [
      { name: "Signals & Systems", marks: 90, max: 100, grade: "A+" },
      { name: "Digital Electronics", marks: 82, max: 100, grade: "A" },
      { name: "Electromagnetics", marks: 76, max: 100, grade: "B+" },
      { name: "Control Systems", marks: 88, max: 100, grade: "A" },
      { name: "Microprocessors", marks: 70, max: 100, grade: "B+" },
    ],
    4: [
      { name: "Data Structures & Algorithms", marks: 95, max: 100, grade: "A+" },
      { name: "Machine Learning", marks: 88, max: 100, grade: "A" },
      { name: "Web Development", marks: 91, max: 100, grade: "A+" },
      { name: "Cloud Computing", marks: 84, max: 100, grade: "A" },
      { name: "Cyber Security", marks: 79, max: 100, grade: "B+" },
    ],
  },
};

const MOCK_API = {
  verifyCollege: async (n) => { await wait(700); const c = MOCK_DB.colleges.find((x) => x.name === n.toLowerCase().trim()); return c ? { found: true, collegeId: c.college_id, displayName: c.display } : { found: false }; },
  verifyRoll: async (roll, cid) => { await wait(600); const s = MOCK_DB.students.find((x) => x.roll.toLowerCase() === roll.toLowerCase().trim() && x.cid === cid); return s ? { found: true, studentId: s.id, course: s.course, semester: s.semester } : { found: false }; },
  verifyName: async (name, sid) => { await wait(500); const s = MOCK_DB.students.find((x) => x.id === sid); if (!s) return { matched: false }; const a = name.toLowerCase().trim(), b = s.name; return { matched: a === b || a.includes(b) || b.includes(a), displayName: s.display }; },
  getResult: async (sid) => { await wait(800); const r = MOCK_DB.results[sid]; if (!r) return { found: false }; const tot = r.reduce((s, x) => s + x.marks, 0), mx = r.reduce((s, x) => s + x.max, 0), pct = Math.round((tot / mx) * 100); let g = "F"; if (pct >= 90) g = "A+"; else if (pct >= 80) g = "A"; else if (pct >= 70) g = "B+"; else if (pct >= 60) g = "B"; else if (pct >= 50) g = "C"; else if (pct >= 40) g = "D"; return { found: true, resultCard: { subjects: r, total: `${tot}/${mx}`, pct, overallGrade: g } }; },
  checkReg: async (sid) => { await wait(400); const s = MOCK_DB.students.find((x) => x.id === sid); return { registered: s?.reg || false }; },
};

// ─── LIVE API (talks to your real backend + SQL Server) ──────────

const post = async (url, body) => {
  const res = await fetch(`${API_BASE}${url}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  return res.json();
};

const LIVE_API = {
  verifyCollege: (n) => post("/api/verify-college", { collegeName: n }),
  verifyRoll: (r, c) => post("/api/verify-rollnumber", { rollNumber: r, collegeId: c }),
  verifyName: (n, s) => post("/api/verify-name", { name: n, studentId: s }),
  getResult: (s) => post("/api/get-resultcard", { studentId: s }),
  checkReg: (s) => post("/api/check-registration", { studentId: s }),
};

// ╔═══════════════════════════════════════════════════════════════╗
// ║                                                               ║
// ║   👇👇👇  CHANGE THIS LINE TO GO LIVE  👇👇👇               ║
// ║                                                               ║
// ║   Demo mode  → export default MOCK_API;                       ║
// ║   Live mode  → export default LIVE_API;                       ║
// ║                                                               ║
// ╚═══════════════════════════════════════════════════════════════╝

export default MOCK_API;
