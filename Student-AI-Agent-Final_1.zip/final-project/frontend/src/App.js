import React from "react";
import StudentAgent from "./StudentAgent";

export default function App() {
  return (
    <div style={{
      display: "flex", alignItems: "center", justifyContent: "center",
      minHeight: "100vh", padding: 20, background: "#060A16",
    }}>
      <div style={{ width: "100%", maxWidth: 520 }}>
        <StudentAgent />
      </div>
    </div>
  );
}
