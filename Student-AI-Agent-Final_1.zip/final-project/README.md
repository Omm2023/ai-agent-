# ╔═══════════════════════════════════════════════════════════════╗
# ║          STUDENT AI AGENT — COMPLETE PROJECT                  ║
# ╚═══════════════════════════════════════════════════════════════╝
#
# WHAT'S INSIDE:
#
#   student-agent/
#   ├── backend/
#   │   ├── server.js              ← API server (edit SQL credentials at top)
#   │   ├── setup-database.js      ← Run once to create tables
#   │   └── package.json           ← Dependencies
#   └── frontend/
#       ├── src/
#       │   ├── api.js             ← ⚡ Switch MOCK → LIVE here (last line)
#       │   ├── StudentAgent.jsx   ← The agent UI (don't edit)
#       │   ├── App.js             ← App wrapper (don't edit)
#       │   └── index.js           ← Entry point (don't edit)
#       ├── public/index.html      ← HTML shell
#       └── package.json           ← Dependencies
#
#
# HOW TO RUN:
#
#   STEP 1 — Backend:
#     cd backend
#     npm install
#     → Edit server.js line 20-25 with your SQL Server credentials
#     → Edit setup-database.js line 10-15 with SAME credentials
#     node setup-database.js
#     npm run dev
#
#   STEP 2 — Frontend:
#     cd frontend
#     npm install
#     npm start
#
#   STEP 3 — Go Live:
#     → Open frontend/src/api.js
#     → Last line: change MOCK_API to LIVE_API
#     → Save. Done.
