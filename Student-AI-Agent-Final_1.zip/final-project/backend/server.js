const express = require("express");
const cors = require("cors");
const sql = require("mssql");

const app = express();
app.use(cors());
app.use(express.json());

// ╔═══════════════════════════════════════════════════════════════════╗
// ║                                                                   ║
// ║   👇👇👇  ENTER YOUR SQL SERVER DETAILS BELOW  👇👇👇           ║
// ║                                                                   ║
// ║   Fill in your real SQL Server credentials here.                  ║
// ║   This is the ONLY thing you need to change in this file.         ║
// ║                                                                   ║
// ╚═══════════════════════════════════════════════════════════════════╝

const DB_CONFIG = {
  server: "localhost",              // ← Your SQL Server address (IP or hostname)
  port: 1433,                       // ← Your SQL Server port (default: 1433)
  database: "student_agent_db",     // ← Your database name
  user: "sa",                       // ← Your SQL Server username
  password: "YOUR_PASSWORD_HERE",   // ← 🔑 YOUR SQL SERVER PASSWORD HERE
  options: {
    encrypt: true,
    trustServerCertificate: true,   // Set false in production with proper SSL certs
  },
};

// ═══════════════════════════════════════════════════════════════════
//  ❌ DO NOT EDIT BELOW THIS LINE — everything is already wired ❌
// ═══════════════════════════════════════════════════════════════════

const PORT = 5000;
let pool;

async function connectDB() {
  try {
    pool = await sql.connect(DB_CONFIG);
    console.log("✅ Connected to SQL Server: " + DB_CONFIG.server + "/" + DB_CONFIG.database);
  } catch (err) {
    console.error("❌ Database connection failed:", err.message);
    console.error("   Check your DB_CONFIG values at the top of this file.");
    process.exit(1);
  }
}

// ─── ENDPOINT 1: Verify College ───────────────────────────────────
app.post("/api/verify-college", async (req, res) => {
  try {
    const { collegeName } = req.body;
    if (!collegeName) return res.status(400).json({ found: false, error: "College name required" });

    const result = await pool.request()
      .input("name", sql.NVarChar, collegeName.trim())
      .query("SELECT college_id, college_name FROM colleges WHERE LOWER(college_name) = LOWER(@name)");

    if (result.recordset.length > 0) {
      res.json({ found: true, collegeId: result.recordset[0].college_id, displayName: result.recordset[0].college_name });
    } else {
      res.json({ found: false });
    }
  } catch (err) {
    console.error("verify-college:", err.message);
    res.status(500).json({ found: false, error: "Server error" });
  }
});

// ─── ENDPOINT 2: Verify Roll Number ──────────────────────────────
app.post("/api/verify-rollnumber", async (req, res) => {
  try {
    const { rollNumber, collegeId } = req.body;
    if (!rollNumber || !collegeId) return res.status(400).json({ found: false, error: "Roll number and college ID required" });

    const result = await pool.request()
      .input("roll", sql.NVarChar, rollNumber.trim())
      .input("cid", sql.Int, collegeId)
      .query("SELECT student_id, course FROM students WHERE roll_number = @roll AND college_id = @cid");

    if (result.recordset.length > 0) {
      res.json({ found: true, studentId: result.recordset[0].student_id, course: result.recordset[0].course });
    } else {
      res.json({ found: false });
    }
  } catch (err) {
    console.error("verify-rollnumber:", err.message);
    res.status(500).json({ found: false, error: "Server error" });
  }
});

// ─── ENDPOINT 3: Verify Student Name ─────────────────────────────
app.post("/api/verify-name", async (req, res) => {
  try {
    const { name, studentId } = req.body;
    if (!name || !studentId) return res.status(400).json({ matched: false, error: "Name and student ID required" });

    const result = await pool.request()
      .input("sid", sql.Int, studentId)
      .query("SELECT student_name FROM students WHERE student_id = @sid");

    if (result.recordset.length > 0) {
      const dbName = result.recordset[0].student_name.toLowerCase().trim();
      const inputName = name.toLowerCase().trim();
      const matched = dbName === inputName || dbName.includes(inputName) || inputName.includes(dbName);
      res.json({ matched, displayName: result.recordset[0].student_name });
    } else {
      res.json({ matched: false });
    }
  } catch (err) {
    console.error("verify-name:", err.message);
    res.status(500).json({ matched: false, error: "Server error" });
  }
});

// ─── ENDPOINT 4: Get Result Card ─────────────────────────────────
app.post("/api/get-resultcard", async (req, res) => {
  try {
    const { studentId } = req.body;
    if (!studentId) return res.status(400).json({ found: false, error: "Student ID required" });

    const result = await pool.request()
      .input("sid", sql.Int, studentId)
      .query("SELECT subject_name, marks_obtained, max_marks, grade FROM results WHERE student_id = @sid ORDER BY subject_name");

    if (result.recordset.length > 0) {
      const subjects = result.recordset.map((r) => ({
        name: r.subject_name, marks: r.marks_obtained, max: r.max_marks, grade: r.grade,
      }));
      const tot = subjects.reduce((s, x) => s + x.marks, 0);
      const mx = subjects.reduce((s, x) => s + x.max, 0);
      const pct = Math.round((tot / mx) * 100);
      let overallGrade = "F";
      if (pct >= 90) overallGrade = "A+";
      else if (pct >= 80) overallGrade = "A";
      else if (pct >= 70) overallGrade = "B+";
      else if (pct >= 60) overallGrade = "B";
      else if (pct >= 50) overallGrade = "C";
      else if (pct >= 40) overallGrade = "D";
      res.json({ found: true, resultCard: { subjects, total: `${tot}/${mx}`, pct, overallGrade } });
    } else {
      res.json({ found: false });
    }
  } catch (err) {
    console.error("get-resultcard:", err.message);
    res.status(500).json({ found: false, error: "Server error" });
  }
});

// ─── ENDPOINT 5: Check Registration ──────────────────────────────
app.post("/api/check-registration", async (req, res) => {
  try {
    const { studentId } = req.body;
    if (!studentId) return res.status(400).json({ registered: false, error: "Student ID required" });

    const result = await pool.request()
      .input("sid", sql.Int, studentId)
      .query("SELECT is_registered FROM students WHERE student_id = @sid");

    if (result.recordset.length > 0) {
      res.json({ registered: result.recordset[0].is_registered === true || result.recordset[0].is_registered === 1 });
    } else {
      res.json({ registered: false });
    }
  } catch (err) {
    console.error("check-registration:", err.message);
    res.status(500).json({ registered: false, error: "Server error" });
  }
});

// ─── Health Check ────────────────────────────────────────────────
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", database: DB_CONFIG.database, server: DB_CONFIG.server });
});

// ─── Start ───────────────────────────────────────────────────────
connectDB().then(() => {
  app.listen(PORT, () => {
    console.log("✅ Server running on http://localhost:" + PORT);
    console.log("   POST /api/verify-college");
    console.log("   POST /api/verify-rollnumber");
    console.log("   POST /api/verify-name");
    console.log("   POST /api/get-resultcard");
    console.log("   POST /api/check-registration");
    console.log("   GET  /api/health");
  });
});
