const sql = require("mssql");

// ╔═══════════════════════════════════════════════════════════════════╗
// ║   Uses the same DB credentials from server.js.                    ║
// ║   Run this ONCE: node setup-database.js                           ║
// ╚═══════════════════════════════════════════════════════════════════╝

const DB_CONFIG = {
  server: "localhost",              // ← Same as server.js
  port: 1433,
  database: "student_agent_db",
  user: "sa",
  password: "YOUR_PASSWORD_HERE",   // ← 🔑 Same password as server.js
  options: { encrypt: true, trustServerCertificate: true },
};

async function setup() {
  let pool;
  try {
    pool = await sql.connect(DB_CONFIG);
    console.log("✅ Connected to SQL Server\n");

    console.log("Creating tables...");

    await pool.request().query(`
      IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'colleges')
      CREATE TABLE colleges (
        college_id    INT IDENTITY(1,1) PRIMARY KEY,
        college_name  NVARCHAR(200) NOT NULL UNIQUE,
        college_code  NVARCHAR(20),
        city          NVARCHAR(100),
        state         NVARCHAR(100),
        created_at    DATETIME DEFAULT GETDATE()
      );
    `);
    console.log("  ✅ colleges table ready");

    await pool.request().query(`
      IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'students')
      CREATE TABLE students (
        student_id      INT IDENTITY(1,1) PRIMARY KEY,
        roll_number     NVARCHAR(50) NOT NULL,
        student_name    NVARCHAR(200) NOT NULL,
        college_id      INT NOT NULL FOREIGN KEY REFERENCES colleges(college_id),
        email           NVARCHAR(200),
        phone           NVARCHAR(20),
        course          NVARCHAR(100),
        semester        INT,
        is_registered   BIT DEFAULT 1,
        created_at      DATETIME DEFAULT GETDATE(),
        UNIQUE (roll_number, college_id)
      );
    `);
    console.log("  ✅ students table ready");

    await pool.request().query(`
      IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'results')
      CREATE TABLE results (
        result_id       INT IDENTITY(1,1) PRIMARY KEY,
        student_id      INT NOT NULL FOREIGN KEY REFERENCES students(student_id),
        subject_name    NVARCHAR(200) NOT NULL,
        marks_obtained  INT NOT NULL,
        max_marks       INT NOT NULL DEFAULT 100,
        grade           NVARCHAR(5),
        exam_year       INT,
        created_at      DATETIME DEFAULT GETDATE()
      );
    `);
    console.log("  ✅ results table ready");

    // Check if data already exists
    const existing = await pool.request().query("SELECT COUNT(*) as cnt FROM colleges");
    if (existing.recordset[0].cnt > 0) {
      console.log("\n⚠️  Sample data already exists. Skipping insert.");
    } else {
      console.log("\nInserting sample data...");

      await pool.request().query(`
        INSERT INTO colleges (college_name, college_code, city, state) VALUES
        ('Delhi Technical University', 'DTU', 'Delhi', 'Delhi'),
        ('Mumbai Institute of Technology', 'MIT-M', 'Mumbai', 'Maharashtra'),
        ('Bangalore Engineering College', 'BEC', 'Bangalore', 'Karnataka');
      `);
      console.log("  ✅ 3 colleges inserted");

      await pool.request().query(`
        INSERT INTO students (roll_number, student_name, college_id, email, course, semester, is_registered) VALUES
        ('DTU2024001', 'Aarav Sharma',   1, 'aarav@dtu.ac.in',   'B.Tech CSE', 4, 1),
        ('DTU2024002', 'Priya Patel',    1, 'priya@dtu.ac.in',   'B.Tech ECE', 4, 1),
        ('DTU2024003', 'Rohan Gupta',    1, 'rohan@dtu.ac.in',   'B.Tech ME',  4, 1),
        ('MIT2024001', 'Sneha Reddy',    2, 'sneha@mitm.ac.in',  'B.Tech CSE', 4, 1),
        ('MIT2024002', 'Arjun Singh',    2, 'arjun@mitm.ac.in',  'B.Tech IT',  4, 0),
        ('BEC2024001', 'Kavya Nair',     3, 'kavya@bec.ac.in',   'B.Tech CSE', 4, 1);
      `);
      console.log("  ✅ 6 students inserted");

      await pool.request().query(`
        INSERT INTO results (student_id, subject_name, marks_obtained, max_marks, grade, exam_year) VALUES
        (1, 'Data Structures & Algorithms', 85, 100, 'A',  2025),
        (1, 'Operating Systems',            78, 100, 'B+', 2025),
        (1, 'Database Management Systems',  92, 100, 'A+', 2025),
        (1, 'Computer Networks',            88, 100, 'A',  2025),
        (1, 'Software Engineering',         74, 100, 'B+', 2025),
        (2, 'Signals & Systems',            90, 100, 'A+', 2025),
        (2, 'Digital Electronics',          82, 100, 'A',  2025),
        (2, 'Electromagnetics',             76, 100, 'B+', 2025),
        (2, 'Control Systems',              88, 100, 'A',  2025),
        (2, 'Microprocessors',              70, 100, 'B+', 2025),
        (4, 'Data Structures & Algorithms', 95, 100, 'A+', 2025),
        (4, 'Machine Learning',             88, 100, 'A',  2025),
        (4, 'Web Development',              91, 100, 'A+', 2025),
        (4, 'Cloud Computing',              84, 100, 'A',  2025),
        (4, 'Cyber Security',               79, 100, 'B+', 2025);
      `);
      console.log("  ✅ 15 result records inserted");
      console.log("  ℹ️  Rohan Gupta, Arjun Singh, Kavya Nair → NO results (for testing)");
    }

    console.log("\n══════════════════════════════════════════");
    console.log("  ✅ DATABASE SETUP COMPLETE");
    console.log("══════════════════════════════════════════\n");

  } catch (err) {
    console.error("❌ Setup failed:", err.message);
  } finally {
    if (pool) await pool.close();
    process.exit(0);
  }
}

setup();
