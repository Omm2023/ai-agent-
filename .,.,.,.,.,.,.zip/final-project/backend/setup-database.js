const sql = require("mssql");

// ╔═══════════════════════════════════════════════════════════════════╗
// ║                                                                   ║
// ║   CONNECTION TEST & DATABASE CHECKER                              ║
// ║                                                                   ║
// ║   What this does:                                                 ║
// ║     1. Connects to your SQL Server                                ║
// ║     2. Checks if required tables exist                            ║
// ║     3. Shows record counts and a data preview                     ║
// ║     4. Tells you if you're ready to go                            ║
// ║                                                                   ║
// ║   What this does NOT do:                                          ║
// ║     ❌ Does NOT create any tables                                 ║
// ║     ❌ Does NOT insert, update, or delete anything                ║
// ║     ❌ Does NOT modify your database in any way                   ║
// ║                                                                   ║
// ║   This is 100% READ-ONLY. Safe to run anytime.                   ║
// ║                                                                   ║
// ║   Run:  node setup-database.js                                    ║
// ║                                                                   ║
// ╚═══════════════════════════════════════════════════════════════════╝

// ╔═══════════════════════════════════════════════════════════════════╗
// ║   👇👇👇  ENTER YOUR SQL SERVER DETAILS BELOW  👇👇👇           ║
// ╚═══════════════════════════════════════════════════════════════════╝

const DB_CONFIG = {
  server: "localhost",              // ← Your SQL Server address
  port: 1433,                       // ← Your SQL Server port
  database: "student_agent_db",     // ← Your database name
  user: "sa",                       // ← Your SQL Server username
  password: "YOUR_PASSWORD_HERE",   // ← 🔑 YOUR PASSWORD HERE (same as server.js)
  options: {
    encrypt: true,
    trustServerCertificate: true,
  },
};

// ═══════════════════════════════════════════════════════════════════
//  ❌ DO NOT EDIT BELOW THIS LINE
// ═══════════════════════════════════════════════════════════════════

async function checkDatabase() {
  let pool;
  try {
    pool = await sql.connect(DB_CONFIG);
    console.log("✅ Connected to SQL Server: " + DB_CONFIG.server + "/" + DB_CONFIG.database);
    console.log("");

    // ─── CHECK REQUIRED TABLES EXIST ─────────────────────────

    console.log("Checking required tables...\n");

    const tables = await pool.request().query(`
      SELECT TABLE_NAME 
      FROM INFORMATION_SCHEMA.TABLES 
      WHERE TABLE_TYPE = 'BASE TABLE'
      ORDER BY TABLE_NAME
    `);
    const tableNames = tables.recordset.map(r => r.TABLE_NAME.toLowerCase());

    const required = ["colleges", "students", "results"];
    let allFound = true;

    for (const t of required) {
      if (tableNames.includes(t)) {
        console.log("  ✅ " + t + " table — found");
      } else {
        console.log("  ❌ " + t + " table — NOT FOUND");
        allFound = false;
      }
    }

    // Check optional result_summary table
    if (tableNames.includes("result_summary")) {
      console.log("  ✅ result_summary table — found (optional, used for total/percentage/grade)");
    } else {
      console.log("  ℹ️  result_summary table — not found (optional — system will calculate totals from results)");
    }

    if (!allFound) {
      console.log("\n❌ MISSING REQUIRED TABLES");
      console.log("   The agent needs these tables in your database: colleges, students, results");
      console.log("   Please create them or check that you're pointing to the correct database.");
      console.log("   Current database: " + DB_CONFIG.database);
      return;
    }

    // ─── CHECK TABLE COLUMNS ──────────────────────────────────

    console.log("\nChecking table structure...\n");

    // colleges table
    const collegesCols = await pool.request().query(`
      SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS 
      WHERE TABLE_NAME = 'colleges' ORDER BY ORDINAL_POSITION
    `);
    const cc = collegesCols.recordset.map(r => r.COLUMN_NAME.toLowerCase());
    const reqCollegesCols = ["college_id", "college_name"];
    const missingCC = reqCollegesCols.filter(c => !cc.includes(c));
    if (missingCC.length > 0) {
      console.log("  ⚠️  colleges table missing columns: " + missingCC.join(", "));
    } else {
      console.log("  ✅ colleges table — structure OK (" + cc.join(", ") + ")");
    }

    // students table
    const studentsCols = await pool.request().query(`
      SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS 
      WHERE TABLE_NAME = 'students' ORDER BY ORDINAL_POSITION
    `);
    const sc = studentsCols.recordset.map(r => r.COLUMN_NAME.toLowerCase());
    const reqStudentsCols = ["student_id", "roll_number", "student_name", "college_id", "is_registered"];
    const missingSC = reqStudentsCols.filter(c => !sc.includes(c));
    if (missingSC.length > 0) {
      console.log("  ⚠️  students table missing columns: " + missingSC.join(", "));
    } else {
      console.log("  ✅ students table — structure OK (" + sc.join(", ") + ")");
    }

    // results table
    const resultsCols = await pool.request().query(`
      SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS 
      WHERE TABLE_NAME = 'results' ORDER BY ORDINAL_POSITION
    `);
    const rc = resultsCols.recordset.map(r => r.COLUMN_NAME.toLowerCase());
    const reqResultsCols = ["student_id", "subject_name", "marks_obtained", "max_marks", "grade"];
    const missingRC = reqResultsCols.filter(c => !rc.includes(c));
    if (missingRC.length > 0) {
      console.log("  ⚠️  results table missing columns: " + missingRC.join(", "));
    } else {
      console.log("  ✅ results table — structure OK (" + rc.join(", ") + ")");
    }

    // ─── DATA REPORT ──────────────────────────────────────────

    console.log("\n──────────────────────────────────────────");
    console.log("  YOUR DATABASE STATUS:");
    console.log("──────────────────────────────────────────\n");

    const collegeCount = await pool.request().query("SELECT COUNT(*) as cnt FROM colleges");
    const studentCount = await pool.request().query("SELECT COUNT(*) as cnt FROM students");
    const resultCount  = await pool.request().query("SELECT COUNT(*) as cnt FROM results");

    const c_cnt = collegeCount.recordset[0].cnt;
    const s_cnt = studentCount.recordset[0].cnt;
    const r_cnt = resultCount.recordset[0].cnt;

    console.log("  colleges : " + c_cnt + " records");
    console.log("  students : " + s_cnt + " records");
    console.log("  results  : " + r_cnt + " records");

    if (tableNames.includes("result_summary")) {
      const sumCount = await pool.request().query("SELECT COUNT(*) as cnt FROM result_summary");
      console.log("  summary  : " + sumCount.recordset[0].cnt + " records");
    }

    if (c_cnt === 0 || s_cnt === 0) {
      console.log("\n  ⚠️  Some tables are empty. The agent needs at least:");
      console.log("     - 1 college in the colleges table");
      console.log("     - 1 student in the students table");
      console.log("     - Result rows in the results table for that student");
    } else {
      // Preview colleges
      const previewC = await pool.request().query("SELECT TOP 5 college_name FROM colleges ORDER BY college_id");
      console.log("\n  Colleges:");
      previewC.recordset.forEach(r => console.log("    → " + r.college_name));
      if (c_cnt > 5) console.log("    ... and " + (c_cnt - 5) + " more");

      // Preview students
      const previewS = await pool.request().query("SELECT TOP 5 student_name, roll_number FROM students ORDER BY student_id");
      console.log("\n  Students:");
      previewS.recordset.forEach(r => console.log("    → " + r.student_name + " (" + r.roll_number + ")"));
      if (s_cnt > 5) console.log("    ... and " + (s_cnt - 5) + " more");

      // Preview results
      const previewR = await pool.request().query(`
        SELECT TOP 3 s.student_name, COUNT(r.result_id) as subject_count
        FROM students s JOIN results r ON s.student_id = r.student_id
        GROUP BY s.student_name ORDER BY s.student_name
      `);
      if (previewR.recordset.length > 0) {
        console.log("\n  Results:");
        previewR.recordset.forEach(r => console.log("    → " + r.student_name + " — " + r.subject_count + " subjects"));
      }
    }

    // ─── FINAL VERDICT ────────────────────────────────────────

    console.log("\n══════════════════════════════════════════");
    if (c_cnt > 0 && s_cnt > 0 && r_cnt > 0) {
      console.log("  ✅ ALL GOOD — your database is ready!");
      console.log("══════════════════════════════════════════");
      console.log("\n  Next step: run the server with 'npm run dev'");
    } else {
      console.log("  ⚠️  DATABASE NEEDS DATA");
      console.log("══════════════════════════════════════════");
      console.log("\n  Add your data via SQL Server Management Studio,");
      console.log("  then run this check again.");
    }
    console.log("");

  } catch (err) {
    console.error("❌ Connection failed:", err.message);
    console.error("");
    if (err.message.includes("Login failed")) {
      console.error("   → Wrong username or password. Check DB_CONFIG at the top of this file.");
    } else if (err.message.includes("Could not connect") || err.message.includes("ECONNREFUSED")) {
      console.error("   → Cannot reach SQL Server. Is it running? Check server address and port.");
    } else if (err.message.includes("database") && err.message.includes("not exist")) {
      console.error("   → Database '" + DB_CONFIG.database + "' doesn't exist on this server.");
    } else {
      console.error("   → Check your DB_CONFIG values at the top of this file.");
    }
  } finally {
    if (pool) await pool.close();
    process.exit(0);
  }
}

checkDatabase();
