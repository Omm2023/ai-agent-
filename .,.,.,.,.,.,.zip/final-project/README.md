# ╔═══════════════════════════════════════════════════════════════╗
# ║          STUDENT AI AGENT — COMPLETE PROJECT                  ║
# ║          100% Read-Only — all data from your SQL Server       ║
# ╚═══════════════════════════════════════════════════════════════╝
#
# WHAT'S INSIDE:
#
#   final-project/
#   ├── backend/
#   │   ├── server.js              ← API server (READ-ONLY, pure SELECT queries)
#   │   ├── setup-database.js      ← Connection test & data checker (no writes)
#   │   └── package.json
#   └── frontend/
#       ├── src/
#       │   ├── api.js             ← Backend URL config (one line)
#       │   ├── StudentAgent.jsx   ← The agent UI (don't edit)
#       │   ├── App.js             ← App wrapper
#       │   └── index.js           ← Entry point
#       ├── public/index.html
#       └── package.json
#
#
# YOUR SQL SERVER MUST HAVE THESE TABLES:
#
#   colleges       — college_id, college_name
#   students       — student_id, roll_number, student_name, college_id, is_registered
#   results        — student_id, subject_name, marks_obtained, max_marks, grade
#   result_summary — (OPTIONAL) student_id, total_marks, total_max, percentage, overall_grade
#
#
# HOW TO RUN:
#
#   STEP 1 — Fill credentials (2 files, same password):
#     → backend/server.js          line 23  → password
#     → backend/setup-database.js  line 34  → password
#
#   STEP 2 — Test connection:
#     cd backend
#     npm install
#     npm run check-db             ← verifies tables & shows your data
#
#   STEP 3 — Start backend:
#     npm run dev                  ← starts on http://localhost:5000
#
#   STEP 4 — Start frontend:
#     cd frontend
#     npm install
#     npm start                    ← opens http://localhost:3000
#
#   Done. The agent reads everything from your SQL Server.
