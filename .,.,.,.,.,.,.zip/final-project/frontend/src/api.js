// ═══════════════════════════════════════════════════════════════
//
//   API CONFIGURATION
//
//   This file connects the frontend to your backend server.
//   All data comes from your SQL Server — nothing is hardcoded.
//
//   The ONLY thing you may need to change is the URL below
//   if your backend runs on a different machine.
//
// ═══════════════════════════════════════════════════════════════

// ╔═══════════════════════════════════════════════════════════════╗
// ║                                                               ║
// ║   👇👇👇  YOUR BACKEND SERVER URL  👇👇👇                   ║
// ║                                                               ║
// ║   If backend is on same computer → leave as localhost         ║
// ║   If backend is on another machine → put that IP/hostname    ║
// ║                                                               ║
// ╚═══════════════════════════════════════════════════════════════╝

const API_BASE = "http://localhost:5000";

// ═══════════════════════════════════════════════════════════════
//  ❌ DO NOT EDIT BELOW THIS LINE
// ═══════════════════════════════════════════════════════════════

const post = async (url, body) => {
  const res = await fetch(`${API_BASE}${url}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    throw new Error(`Server error: ${res.status}`);
  }
  return res.json();
};

const API = {
  verifyCollege: (name) => post("/api/verify-college", { collegeName: name }),
  verifyRoll: (roll, collegeId) => post("/api/verify-rollnumber", { rollNumber: roll, collegeId }),
  verifyName: (name, studentId) => post("/api/verify-name", { name, studentId }),
  getResult: (studentId) => post("/api/get-resultcard", { studentId }),
  checkReg: (studentId) => post("/api/check-registration", { studentId }),
};

export default API;
