import React from "react";
import StudentAgent from "./StudentAgent";

export default function App() {
  return (
    <div style={{
      minHeight: "100vh",
      background: "#060A16",
      display: "flex",
      flexDirection: "column",
      fontFamily: "'Outfit', system-ui, sans-serif",
    }}>

      {/* ── PAGE HEADER ── */}
      <header style={{
        padding: "20px 24px",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        borderBottom: "1px solid rgba(0,255,212,0.05)",
        background: "linear-gradient(180deg, rgba(8,12,24,0.98), rgba(6,10,22,0.9))",
        backdropFilter: "blur(20px)",
        position: "sticky",
        top: 0,
        zIndex: 100,
      }}>
        {/* Left: Logo + Title */}
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <div style={{
            width: 38, height: 38, borderRadius: 10,
            background: "linear-gradient(135deg, rgba(0,255,212,0.1), rgba(10,132,255,0.1))",
            border: "1px solid rgba(0,255,212,0.15)",
            display: "flex", alignItems: "center", justifyContent: "center",
          }}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#00FFD4" strokeWidth="1.6" strokeLinecap="round">
              <path d="M22 10v6M2 10l10-5 10 5-10 5z"/>
              <path d="M6 12v5c0 1.5 3 3 6 3s6-1.5 6-3v-5"/>
            </svg>
          </div>
          <div>
            <div style={{
              fontSize: 16, fontWeight: 700, color: "#E4EAF8",
              letterSpacing: "0.02em",
            }}>
              Student AI Agent
            </div>
            <div style={{
              fontSize: 9, color: "rgba(0,255,212,0.3)",
              letterSpacing: "0.12em", fontWeight: 500, marginTop: 2,
              fontFamily: "'Share Tech Mono', monospace",
            }}>
              ACADEMIC VERIFICATION SYSTEM
            </div>
          </div>
        </div>

        {/* Right: Status indicator */}
        <div style={{
          display: "flex", alignItems: "center", gap: 8,
          padding: "6px 14px", borderRadius: 20,
          background: "rgba(0,255,212,0.04)",
          border: "1px solid rgba(0,255,212,0.1)",
        }}>
          <div style={{
            width: 6, height: 6, borderRadius: "50%",
            background: "#00FFD4",
            boxShadow: "0 0 8px rgba(0,255,212,0.5)",
            animation: "statusPulse 2s ease-in-out infinite",
          }} />
          <span style={{
            fontSize: 10, color: "rgba(0,255,212,0.5)",
            fontFamily: "'Share Tech Mono', monospace",
            fontWeight: 500, letterSpacing: "0.08em",
          }}>ONLINE</span>
        </div>
      </header>

      {/* ── MAIN CONTENT ── */}
      <main style={{
        flex: 1,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "32px 20px",
        position: "relative",
      }}>
        {/* Background grid */}
        <div style={{
          position: "absolute", inset: 0,
          backgroundImage: `
            linear-gradient(rgba(0,255,212,0.015) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0,255,212,0.015) 1px, transparent 1px)
          `,
          backgroundSize: "60px 60px",
          pointerEvents: "none",
        }} />

        {/* Radial glow behind agent */}
        <div style={{
          position: "absolute",
          width: 600, height: 600,
          borderRadius: "50%",
          background: "radial-gradient(circle, rgba(0,255,212,0.03) 0%, transparent 70%)",
          pointerEvents: "none",
        }} />

        <div style={{
          width: "100%", maxWidth: 520,
          position: "relative", zIndex: 1,
        }}>
          <StudentAgent />
        </div>
      </main>

      {/* ── PAGE FOOTER ── */}
      <footer style={{
        padding: "16px 24px",
        borderTop: "1px solid rgba(0,255,212,0.04)",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        flexWrap: "wrap",
        gap: 12,
      }}>
        <div style={{
          fontSize: 10, color: "rgba(255,255,255,0.12)",
          fontFamily: "'Share Tech Mono', monospace",
          letterSpacing: "0.06em",
        }}>
          STUDENT AI AGENT v2.4
        </div>
        <div style={{
          display: "flex", alignItems: "center", gap: 16,
        }}>
          <span style={{
            fontSize: 10, color: "rgba(255,255,255,0.1)",
            fontFamily: "'Share Tech Mono', monospace",
          }}>
            ENCRYPTED CONNECTION
          </span>
          <div style={{
            display: "flex", gap: 3,
          }}>
            {[0,1,2].map(i => (
              <div key={i} style={{
                width: 3, height: 3, borderRadius: "50%",
                background: "rgba(0,255,212,0.2)",
              }} />
            ))}
          </div>
        </div>
      </footer>

      <style>{`
        @keyframes statusPulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.4; }
        }
      `}</style>
    </div>
  );
}
