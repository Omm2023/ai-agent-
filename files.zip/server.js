// ═══════════════════════════════════════════════════════════════
//  STUDENT RESULT VERIFICATION — BACKEND SERVER
//  Stack: Node.js + Express + mssql (Microsoft SQL Server)
// ═══════════════════════════════════════════════════════════════

const express = require("express");
const cors = require("cors");
const sql = require("mssql");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 5000;

// ─── MIDDLEWARE ───
app.use(cors());
app.use(express.json());

// ─── SQL SERVER CONFIG ───
// These values come from your .env file
const dbConfig = {
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  server: process.env.DB_SERVER,       // e.g. "localhost" or "myserver.database.windows.net"
  database: process.env.DB_NAME,
  port: parseInt(process.env.DB_PORT) || 1433,
  options: {
    encrypt: true,                      // Required for Azure SQL
    trustServerCertificate: true,       // Set false in production with proper certs
  },
};

// ─── DATABASE CONNECTION POOL ───
let pool;

async function connectDB() {
  try {
    pool = await sql.connect(dbConfig);
    console.log("Connected to SQL Server successfully");
  } catch (err) {
    console.error("Database connection failed:", err.message);
    process.exit(1);
  }
}

// ═══════════════════════════════════════════════════════════════
//  API ENDPOINTS
// ═══════════════════════════════════════════════════════════════

// ─── 1. VERIFY COLLEGE ───
// Checks if the college name exists in the database
app.post("/api/verify-college", async (req, res) => {
  try {
    const { collegeName } = req.body;

    if (!collegeName) {
      return res.status(400).json({ found: false, error: "College name is required" });
    }

    const result = await pool
      .request()
      .input("collegeName", sql.NVarChar, collegeName.trim())
      .query(`
        SELECT college_id, college_name
        FROM colleges
        WHERE LOWER(college_name) = LOWER(@collegeName)
      `);

    if (result.recordset.length > 0) {
      res.json({
        found: true,
        collegeId: result.recordset[0].college_id,
      });
    } else {
      res.json({ found: false });
    }
  } catch (err) {
    console.error("verify-college error:", err.message);
    res.status(500).json({ found: false, error: "Server error" });
  }
});

// ─── 2. VERIFY ROLL NUMBER ───
// Checks if roll number exists under the given college
app.post("/api/verify-rollnumber", async (req, res) => {
  try {
    const { rollNumber, collegeId } = req.body;

    if (!rollNumber || !collegeId) {
      return res.status(400).json({ found: false, error: "Roll number and college ID are required" });
    }

    const result = await pool
      .request()
      .input("rollNumber", sql.NVarChar, rollNumber.trim())
      .input("collegeId", sql.Int, collegeId)
      .query(`
        SELECT student_id, roll_number, student_name
        FROM students
        WHERE roll_number = @rollNumber AND college_id = @collegeId
      `);

    if (result.recordset.length > 0) {
      res.json({
        found: true,
        studentId: result.recordset[0].student_id,
      });
    } else {
      res.json({ found: false });
    }
  } catch (err) {
    console.error("verify-rollnumber error:", err.message);
    res.status(500).json({ found: false, error: "Server error" });
  }
});

// ─── 3. VERIFY STUDENT NAME ───
// Cross-checks the name against the student record
app.post("/api/verify-name", async (req, res) => {
  try {
    const { name, studentId } = req.body;

    if (!name || !studentId) {
      return res.status(400).json({ matched: false, error: "Name and student ID are required" });
    }

    const result = await pool
      .request()
      .input("studentId", sql.Int, studentId)
      .query(`
        SELECT student_name FROM students WHERE student_id = @studentId
      `);

    if (result.recordset.length > 0) {
      const dbName = result.recordset[0].student_name.toLowerCase().trim();
      const inputName = name.toLowerCase().trim();

      // Flexible match: exact or the DB name contains the input (or vice versa)
      const matched = dbName === inputName ||
                      dbName.includes(inputName) ||
                      inputName.includes(dbName);

      res.json({ matched });
    } else {
      res.json({ matched: false });
    }
  } catch (err) {
    console.error("verify-name error:", err.message);
    res.status(500).json({ matched: false, error: "Server error" });
  }
});

// ─── 4. GET RESULT CARD ───
// Fetches the student's marksheet / result card
app.post("/api/get-resultcard", async (req, res) => {
  try {
    const { studentId } = req.body;

    if (!studentId) {
      return res.status(400).json({ found: false, error: "Student ID is required" });
    }

    const result = await pool
      .request()
      .input("studentId", sql.Int, studentId)
      .query(`
        SELECT
          r.subject_name,
          r.marks_obtained,
          r.max_marks,
          r.grade
        FROM results r
        WHERE r.student_id = @studentId
        ORDER BY r.subject_name
      `);

    if (result.recordset.length > 0) {
      // Calculate total
      const subjects = result.recordset.map((row) => ({
        name: row.subject_name,
        marks: `${row.marks_obtained}/${row.max_marks}`,
        grade: row.grade,
      }));

      const totalObtained = result.recordset.reduce((sum, r) => sum + r.marks_obtained, 0);
      const totalMax = result.recordset.reduce((sum, r) => sum + r.max_marks, 0);
      const percentage = Math.round((totalObtained / totalMax) * 100);

      let overallGrade = "F";
      if (percentage >= 90) overallGrade = "A+";
      else if (percentage >= 80) overallGrade = "A";
      else if (percentage >= 70) overallGrade = "B+";
      else if (percentage >= 60) overallGrade = "B";
      else if (percentage >= 50) overallGrade = "C";
      else if (percentage >= 40) overallGrade = "D";

      res.json({
        found: true,
        resultCard: {
          subjects,
          total: `${totalObtained}/${totalMax} (${percentage}%)`,
          overallGrade,
        },
      });
    } else {
      res.json({ found: false });
    }
  } catch (err) {
    console.error("get-resultcard error:", err.message);
    res.status(500).json({ found: false, error: "Server error" });
  }
});

// ─── 5. CHECK REGISTRATION ───
// Checks if the student is registered (enrolled) but has no results
app.post("/api/check-registration", async (req, res) => {
  try {
    const { studentId } = req.body;

    if (!studentId) {
      return res.status(400).json({ registered: false, error: "Student ID is required" });
    }

    const result = await pool
      .request()
      .input("studentId", sql.Int, studentId)
      .query(`
        SELECT is_registered FROM students WHERE student_id = @studentId
      `);

    if (result.recordset.length > 0) {
      res.json({
        registered: result.recordset[0].is_registered === true ||
                    result.recordset[0].is_registered === 1,
      });
    } else {
      res.json({ registered: false });
    }
  } catch (err) {
    console.error("check-registration error:", err.message);
    res.status(500).json({ registered: false, error: "Server error" });
  }
});

// ─── HEALTH CHECK ───
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", db: pool?.connected ? "connected" : "disconnected" });
});

// ─── START SERVER ───
connectDB().then(() => {
  app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
});
