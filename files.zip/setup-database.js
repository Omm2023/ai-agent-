// ═══════════════════════════════════════════════════════════════
//  DATABASE SETUP SCRIPT
//  Run once: node setup-database.js
//  Creates all tables and inserts sample data for testing
// ═══════════════════════════════════════════════════════════════

const sql = require("mssql");
require("dotenv").config();

const dbConfig = {
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  server: process.env.DB_SERVER,
  database: process.env.DB_NAME,
  port: parseInt(process.env.DB_PORT) || 1433,
  options: {
    encrypt: true,
    trustServerCertificate: true,
  },
};

async function setupDatabase() {
  let pool;

  try {
    pool = await sql.connect(dbConfig);
    console.log("Connected to SQL Server\n");

    // ─── CREATE TABLES ───
    console.log("Creating tables...");

    await pool.request().query(`
      -- Colleges table
      IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'colleges')
      CREATE TABLE colleges (
        college_id    INT IDENTITY(1,1) PRIMARY KEY,
        college_name  NVARCHAR(200) NOT NULL UNIQUE,
        college_code  NVARCHAR(20),
        city          NVARCHAR(100),
        state         NVARCHAR(100),
        created_at    DATETIME DEFAULT GETDATE()
      );
    `);
    console.log("  colleges table ready");

    await pool.request().query(`
      -- Students table
      IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'students')
      CREATE TABLE students (
        student_id      INT IDENTITY(1,1) PRIMARY KEY,
        roll_number     NVARCHAR(50) NOT NULL,
        student_name    NVARCHAR(200) NOT NULL,
        college_id      INT NOT NULL FOREIGN KEY REFERENCES colleges(college_id),
        email           NVARCHAR(200),
        phone           NVARCHAR(20),
        course          NVARCHAR(100),
        semester        INT,
        is_registered   BIT DEFAULT 1,
        created_at      DATETIME DEFAULT GETDATE(),
        UNIQUE (roll_number, college_id)
      );
    `);
    console.log("  students table ready");

    await pool.request().query(`
      -- Results table
      IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'results')
      CREATE TABLE results (
        result_id       INT IDENTITY(1,1) PRIMARY KEY,
        student_id      INT NOT NULL FOREIGN KEY REFERENCES students(student_id),
        subject_name    NVARCHAR(200) NOT NULL,
        marks_obtained  INT NOT NULL,
        max_marks       INT NOT NULL DEFAULT 100,
        grade           NVARCHAR(5),
        exam_year       INT,
        created_at      DATETIME DEFAULT GETDATE()
      );
    `);
    console.log("  results table ready");

    // ─── INSERT SAMPLE DATA ───
    console.log("\nInserting sample data...");

    // Check if data already exists
    const existing = await pool.request().query("SELECT COUNT(*) as cnt FROM colleges");
    if (existing.recordset[0].cnt > 0) {
      console.log("  Sample data already exists, skipping insert.");
    } else {
      // Colleges
      await pool.request().query(`
        INSERT INTO colleges (college_name, college_code, city, state) VALUES
        ('Delhi Technical University', 'DTU', 'Delhi', 'Delhi'),
        ('Mumbai Institute of Technology', 'MIT-M', 'Mumbai', 'Maharashtra'),
        ('Bangalore Engineering College', 'BEC', 'Bangalore', 'Karnataka');
      `);
      console.log("  3 colleges inserted");

      // Students
      await pool.request().query(`
        INSERT INTO students (roll_number, student_name, college_id, email, course, semester, is_registered) VALUES
        ('DTU2024001', 'Aarav Sharma',   1, 'aarav@dtu.ac.in',   'B.Tech CSE', 4, 1),
        ('DTU2024002', 'Priya Patel',    1, 'priya@dtu.ac.in',   'B.Tech ECE', 4, 1),
        ('DTU2024003', 'Rohan Gupta',    1, 'rohan@dtu.ac.in',   'B.Tech ME',  4, 1),
        ('MIT2024001', 'Sneha Reddy',    2, 'sneha@mitm.ac.in',  'B.Tech CSE', 4, 1),
        ('MIT2024002', 'Arjun Singh',    2, 'arjun@mitm.ac.in',  'B.Tech IT',  4, 0),
        ('BEC2024001', 'Kavya Nair',     3, 'kavya@bec.ac.in',   'B.Tech CSE', 4, 1);
      `);
      console.log("  6 students inserted");

      // Results (only for some students — to test the "no result card" flow)
      await pool.request().query(`
        INSERT INTO results (student_id, subject_name, marks_obtained, max_marks, grade, exam_year) VALUES
        -- Aarav Sharma (DTU2024001) - has results
        (1, 'Data Structures',        85, 100, 'A',  2025),
        (1, 'Operating Systems',      78, 100, 'B+', 2025),
        (1, 'Database Management',    92, 100, 'A+', 2025),
        (1, 'Computer Networks',      88, 100, 'A',  2025),
        (1, 'Software Engineering',   74, 100, 'B+', 2025),

        -- Priya Patel (DTU2024002) - has results
        (2, 'Signals & Systems',      90, 100, 'A+', 2025),
        (2, 'Digital Electronics',    82, 100, 'A',  2025),
        (2, 'Electromagnetics',       76, 100, 'B+', 2025),
        (2, 'Control Systems',        88, 100, 'A',  2025),
        (2, 'Microprocessors',        70, 100, 'B+', 2025),

        -- Sneha Reddy (MIT2024001) - has results
        (4, 'Data Structures',        95, 100, 'A+', 2025),
        (4, 'Machine Learning',       88, 100, 'A',  2025),
        (4, 'Web Development',        91, 100, 'A+', 2025),
        (4, 'Cloud Computing',        84, 100, 'A',  2025),
        (4, 'Cyber Security',         79, 100, 'B+', 2025);

        -- Rohan Gupta (DTU2024003) - registered but NO results (triggers alert)
        -- Arjun Singh (MIT2024002)  - NOT registered (is_registered = 0), no results
        -- Kavya Nair  (BEC2024001)  - registered but NO results (triggers alert)
      `);
      console.log("  15 result records inserted");
      console.log("  (Rohan, Arjun, Kavya have no results for testing)");
    }

    console.log("\n Database setup complete!");
    console.log("\n── Test scenarios ──────────────────────────────────────");
    console.log("  Aarav Sharma  | DTU2024001 | Delhi Technical University  → has results");
    console.log("  Priya Patel   | DTU2024002 | Delhi Technical University  → has results");
    console.log("  Rohan Gupta   | DTU2024003 | Delhi Technical University  → registered, no results (trigger)");
    console.log("  Sneha Reddy   | MIT2024001 | Mumbai Institute of Technology → has results");
    console.log("  Arjun Singh   | MIT2024002 | Mumbai Institute of Technology → NOT registered");
    console.log("  Kavya Nair    | BEC2024001 | Bangalore Engineering College  → registered, no results (trigger)");
    console.log("────────────────────────────────────────────────────────\n");

  } catch (err) {
    console.error("Setup failed:", err.message);
  } finally {
    if (pool) await pool.close();
    process.exit(0);
  }
}

setupDatabase();
