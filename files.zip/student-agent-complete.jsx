import { useState, useRef, useEffect, useCallback } from "react";

/* ═══════════════════════════════════════════════════════════════════
   STUDENT RESULT VERIFICATION AI AGENT
   ─────────────────────────────────────
   Complete self-contained agent with:
   • Multi-step identity verification (college → roll → name)
   • Result card lookup & display
   • Registration status check
   • "Contact admin" fallback
   • Mock DB for demo — swap API_BASE for production
   ═══════════════════════════════════════════════════════════════════ */

// ── MOCK DATABASE ──────────────────────────────────────────────────
// Replace this entire section with real fetch() calls to your backend.
// See API_MODE below to switch between mock and live.

const MOCK_DB = {
  colleges: [
    { college_id: 1, college_name: "delhi technical university", display: "Delhi Technical University" },
    { college_id: 2, college_name: "mumbai institute of technology", display: "Mumbai Institute of Technology" },
    { college_id: 3, college_name: "bangalore engineering college", display: "Bangalore Engineering College" },
  ],
  students: [
    { student_id: 1, roll_number: "DTU2024001", student_name: "aarav sharma", display_name: "Aarav Sharma", college_id: 1, course: "B.Tech CSE", is_registered: true },
    { student_id: 2, roll_number: "DTU2024002", student_name: "priya patel", display_name: "Priya Patel", college_id: 1, course: "B.Tech ECE", is_registered: true },
    { student_id: 3, roll_number: "DTU2024003", student_name: "rohan gupta", display_name: "Rohan Gupta", college_id: 1, course: "B.Tech ME", is_registered: true },
    { student_id: 4, roll_number: "MIT2024001", student_name: "sneha reddy", display_name: "Sneha Reddy", college_id: 2, course: "B.Tech CSE", is_registered: true },
    { student_id: 5, roll_number: "MIT2024002", student_name: "arjun singh", display_name: "Arjun Singh", college_id: 2, course: "B.Tech IT", is_registered: false },
    { student_id: 6, roll_number: "BEC2024001", student_name: "kavya nair", display_name: "Kavya Nair", college_id: 3, course: "B.Tech CSE", is_registered: true },
  ],
  results: {
    1: { subjects: [
      { name: "Data Structures", marks: "85/100", grade: "A" },
      { name: "Operating Systems", marks: "78/100", grade: "B+" },
      { name: "Database Management", marks: "92/100", grade: "A+" },
      { name: "Computer Networks", marks: "88/100", grade: "A" },
      { name: "Software Engineering", marks: "74/100", grade: "B+" },
    ], total: "417/500 (83%)", overallGrade: "A" },
    2: { subjects: [
      { name: "Signals & Systems", marks: "90/100", grade: "A+" },
      { name: "Digital Electronics", marks: "82/100", grade: "A" },
      { name: "Electromagnetics", marks: "76/100", grade: "B+" },
      { name: "Control Systems", marks: "88/100", grade: "A" },
      { name: "Microprocessors", marks: "70/100", grade: "B+" },
    ], total: "406/500 (81%)", overallGrade: "A" },
    4: { subjects: [
      { name: "Data Structures", marks: "95/100", grade: "A+" },
      { name: "Machine Learning", marks: "88/100", grade: "A" },
      { name: "Web Development", marks: "91/100", grade: "A+" },
      { name: "Cloud Computing", marks: "84/100", grade: "A" },
      { name: "Cyber Security", marks: "79/100", grade: "B+" },
    ], total: "437/500 (87%)", overallGrade: "A+" },
  },
};

const delay = (ms) => new Promise((r) => setTimeout(r, ms));

const MOCK_API = {
  verifyCollege: async (collegeName) => {
    await delay(600);
    const c = MOCK_DB.colleges.find((x) => x.college_name === collegeName.toLowerCase().trim());
    return c ? { found: true, collegeId: c.college_id, displayName: c.display } : { found: false };
  },
  verifyRollNumber: async (rollNumber, collegeId) => {
    await delay(500);
    const s = MOCK_DB.students.find((x) => x.roll_number.toLowerCase() === rollNumber.toLowerCase().trim() && x.college_id === collegeId);
    return s ? { found: true, studentId: s.student_id } : { found: false };
  },
  verifyName: async (name, studentId) => {
    await delay(500);
    const s = MOCK_DB.students.find((x) => x.student_id === studentId);
    if (!s) return { matched: false };
    const input = name.toLowerCase().trim();
    const db = s.student_name;
    return { matched: db === input || db.includes(input) || input.includes(db) };
  },
  getResultCard: async (studentId) => {
    await delay(700);
    const r = MOCK_DB.results[studentId];
    return r ? { found: true, resultCard: r } : { found: false };
  },
  checkRegistration: async (studentId) => {
    await delay(400);
    const s = MOCK_DB.students.find((x) => x.student_id === studentId);
    return { registered: s?.is_registered || false };
  },
};

// ── PRODUCTION API (uncomment & set your URL) ──────────────────────
// const API_BASE = "http://localhost:5000";
// const LIVE_API = {
//   verifyCollege: async (collegeName) => {
//     const res = await fetch(`${API_BASE}/api/verify-college`, {
//       method: "POST", headers: { "Content-Type": "application/json" },
//       body: JSON.stringify({ collegeName }),
//     });
//     return res.json();
//   },
//   verifyRollNumber: async (rollNumber, collegeId) => {
//     const res = await fetch(`${API_BASE}/api/verify-rollnumber`, {
//       method: "POST", headers: { "Content-Type": "application/json" },
//       body: JSON.stringify({ rollNumber, collegeId }),
//     });
//     return res.json();
//   },
//   verifyName: async (name, studentId) => {
//     const res = await fetch(`${API_BASE}/api/verify-name`, {
//       method: "POST", headers: { "Content-Type": "application/json" },
//       body: JSON.stringify({ name, studentId }),
//     });
//     return res.json();
//   },
//   getResultCard: async (studentId) => {
//     const res = await fetch(`${API_BASE}/api/get-resultcard`, {
//       method: "POST", headers: { "Content-Type": "application/json" },
//       body: JSON.stringify({ studentId }),
//     });
//     return res.json();
//   },
//   checkRegistration: async (studentId) => {
//     const res = await fetch(`${API_BASE}/api/check-registration`, {
//       method: "POST", headers: { "Content-Type": "application/json" },
//       body: JSON.stringify({ studentId }),
//     });
//     return res.json();
//   },
// };

// Toggle: use MOCK_API for demo, LIVE_API for production
const API = MOCK_API;

// ── FLOW STATES ────────────────────────────────────────────────────
const S = {
  IDLE: 0, ASK_COLLEGE: 1, ASK_ROLL: 2, ASK_NAME: 3,
  VERIFYING: 4, DONE: 5,
};

const TRIGGERS = ["result", "marksheet", "mark sheet", "marks", "scorecard", "score card", "grade", "grades", "not found", "can't find", "cannot find", "where is my"];
const isResultQuery = (t) => TRIGGERS.some((k) => t.toLowerCase().includes(k));

// ── STYLES ─────────────────────────────────────────────────────────
const C = {
  bg: "#0F1117", surface: "#181B24", surface2: "#1E222D",
  border: "#2A2F3C", borderLight: "#353B4A",
  accent: "#6C8EEF", accentDim: "#4A65B8", accentBg: "rgba(108,142,239,0.08)",
  green: "#34D399", greenDim: "#065F46", greenBg: "rgba(52,211,153,0.08)",
  red: "#F87171", redDim: "#7F1D1D", redBg: "rgba(248,113,113,0.06)",
  amber: "#FBBF24", amberBg: "rgba(251,191,36,0.08)",
  text: "#E8EAF0", textMid: "#9CA3B8", textDim: "#5C6378",
  userBubble: "#6C8EEF",
};

// ── COMPONENTS ─────────────────────────────────────────────────────

function Dots() {
  return (
    <div style={{ display: "flex", gap: 6, padding: "8px 4px", alignItems: "center" }}>
      {[0, 1, 2].map((i) => (
        <div key={i} style={{
          width: 6, height: 6, borderRadius: "50%", background: C.textDim,
          animation: `pulse 1.4s ease-in-out ${i * 0.18}s infinite`,
        }} />
      ))}
    </div>
  );
}

function Steps({ current }) {
  const labels = ["College", "Roll number", "Name"];
  return (
    <div style={{ display: "flex", gap: 6, alignItems: "center", padding: "12px 0 4px" }}>
      {labels.map((l, i) => {
        const done = i < current;
        const active = i === current;
        return (
          <div key={i} style={{ display: "flex", alignItems: "center", gap: 5 }}>
            <div style={{
              width: 20, height: 20, borderRadius: "50%",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 10, fontWeight: 700, letterSpacing: "0.02em",
              background: done ? C.green : active ? C.accent : C.surface2,
              color: done || active ? "#fff" : C.textDim,
              border: `1px solid ${done ? C.green : active ? C.accent : C.border}`,
              transition: "all 0.35s cubic-bezier(0.4,0,0.2,1)",
              boxShadow: active ? `0 0 12px ${C.accent}40` : "none",
            }}>
              {done ? "✓" : i + 1}
            </div>
            <span style={{
              fontSize: 11, fontWeight: active ? 600 : 400,
              color: active ? C.accent : done ? C.green : C.textDim,
              transition: "color 0.3s",
            }}>{l}</span>
            {i < 2 && <div style={{
              width: 24, height: 1,
              background: done ? C.green : C.border,
              transition: "background 0.4s",
            }} />}
          </div>
        );
      })}
    </div>
  );
}

function ResultCardDisplay({ data }) {
  if (!data) return null;
  return (
    <div style={{
      background: C.surface2, border: `1px solid ${C.border}`,
      borderRadius: 10, padding: 16, marginTop: 10,
      animation: "slideUp 0.35s ease",
    }}>
      <div style={{
        display: "flex", alignItems: "center", gap: 8,
        marginBottom: 14, paddingBottom: 10,
        borderBottom: `1px solid ${C.border}`,
      }}>
        <div style={{
          width: 8, height: 8, borderRadius: 2, background: C.accent,
          boxShadow: `0 0 8px ${C.accent}60`,
        }} />
        <span style={{
          fontSize: 11, fontWeight: 700, color: C.accent,
          textTransform: "uppercase", letterSpacing: "0.12em",
        }}>Result card</span>
      </div>
      {data.studentName && (
        <div style={{ fontSize: 15, fontWeight: 600, color: C.text, marginBottom: 2 }}>{data.studentName}</div>
      )}
      {data.rollNumber && (
        <div style={{ fontSize: 11, color: C.textDim, marginBottom: 14, letterSpacing: "0.02em" }}>
          {data.rollNumber} &middot; {data.collegeName || ""}
        </div>
      )}
      {data.subjects && (
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
          <thead>
            <tr>
              <th style={{ textAlign: "left", padding: "6px 0", color: C.textDim, fontWeight: 600, borderBottom: `1px solid ${C.border}`, fontSize: 10, textTransform: "uppercase", letterSpacing: "0.08em" }}>Subject</th>
              <th style={{ textAlign: "right", padding: "6px 0", color: C.textDim, fontWeight: 600, borderBottom: `1px solid ${C.border}`, fontSize: 10, textTransform: "uppercase", letterSpacing: "0.08em" }}>Marks</th>
              <th style={{ textAlign: "right", padding: "6px 0", color: C.textDim, fontWeight: 600, borderBottom: `1px solid ${C.border}`, fontSize: 10, textTransform: "uppercase", letterSpacing: "0.08em" }}>Grade</th>
            </tr>
          </thead>
          <tbody>
            {data.subjects.map((s, i) => (
              <tr key={i} style={{ borderBottom: `1px solid ${C.surface}` }}>
                <td style={{ padding: "8px 0", color: C.text }}>{s.name}</td>
                <td style={{ padding: "8px 0", color: C.textMid, textAlign: "right", fontFamily: "'JetBrains Mono', 'Fira Code', monospace", fontSize: 11 }}>{s.marks}</td>
                <td style={{ padding: "8px 0", textAlign: "right" }}>
                  <span style={{
                    display: "inline-block", padding: "2px 8px", borderRadius: 4,
                    fontSize: 10, fontWeight: 700, letterSpacing: "0.04em",
                    background: s.grade === "F" ? C.redBg : s.grade.startsWith("A") ? C.greenBg : C.amberBg,
                    color: s.grade === "F" ? C.red : s.grade.startsWith("A") ? C.green : C.amber,
                    border: `1px solid ${s.grade === "F" ? C.redDim : s.grade.startsWith("A") ? C.greenDim : "#92400E"}40`,
                  }}>{s.grade}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
      {data.total !== undefined && (
        <div style={{
          display: "flex", justifyContent: "space-between", alignItems: "center",
          marginTop: 12, paddingTop: 12,
          borderTop: `1px solid ${C.borderLight}`,
        }}>
          <span style={{ fontWeight: 600, fontSize: 12, color: C.textMid, textTransform: "uppercase", letterSpacing: "0.06em" }}>Total</span>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <span style={{ fontWeight: 700, fontSize: 14, color: C.text, fontFamily: "'JetBrains Mono', 'Fira Code', monospace" }}>{data.total}</span>
            <span style={{
              padding: "3px 10px", borderRadius: 4, fontSize: 11, fontWeight: 700,
              background: C.greenBg, color: C.green, border: `1px solid ${C.greenDim}40`,
            }}>{data.overallGrade}</span>
          </div>
        </div>
      )}
    </div>
  );
}

function StatusBadge({ type, text }) {
  const config = {
    success: { bg: C.greenBg, color: C.green, border: C.greenDim, icon: "✓" },
    error: { bg: C.redBg, color: C.red, border: C.redDim, icon: "✕" },
    warning: { bg: C.amberBg, color: C.amber, border: "#92400E", icon: "!" },
    info: { bg: C.accentBg, color: C.accent, border: C.accentDim, icon: "→" },
  };
  const c = config[type] || config.info;
  return (
    <div style={{
      display: "inline-flex", alignItems: "center", gap: 6,
      padding: "5px 10px", borderRadius: 6, marginTop: 8,
      background: c.bg, border: `1px solid ${c.border}30`,
      fontSize: 11, fontWeight: 600, color: c.color,
    }}>
      <span style={{ fontSize: 10 }}>{c.icon}</span> {text}
    </div>
  );
}

function Bubble({ msg }) {
  const isUser = msg.role === "user";
  return (
    <div style={{
      display: "flex", gap: 10,
      flexDirection: isUser ? "row-reverse" : "row",
      alignSelf: isUser ? "flex-end" : "flex-start",
      maxWidth: "88%",
      animation: "msgIn 0.3s cubic-bezier(0.16,1,0.3,1)",
    }}>
      {!isUser && (
        <div style={{
          width: 30, height: 30, borderRadius: 8, flexShrink: 0, marginTop: 2,
          background: `linear-gradient(135deg, ${C.accent}, ${C.green})`,
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: 13, fontWeight: 800, color: "#fff",
          boxShadow: `0 2px 12px ${C.accent}30`,
        }}>S</div>
      )}
      <div style={{
        padding: "10px 14px",
        borderRadius: isUser ? "14px 14px 4px 14px" : "14px 14px 14px 4px",
        background: isUser ? C.userBubble : C.surface2,
        color: isUser ? "#fff" : C.text,
        fontSize: 13.5, lineHeight: 1.65,
        border: isUser ? "none" : `1px solid ${C.border}`,
        boxShadow: isUser ? `0 2px 12px ${C.accent}25` : "none",
      }}>
        <div>{msg.text}</div>
        {msg.step !== undefined && <Steps current={msg.step} />}
        {msg.badge && <StatusBadge type={msg.badge.type} text={msg.badge.text} />}
        {msg.resultCard && <ResultCardDisplay data={msg.resultCard} />}
      </div>
    </div>
  );
}

// ── MAIN AGENT ─────────────────────────────────────────────────────

export default function StudentAgent() {
  const [msgs, setMsgs] = useState([]);
  const [input, setInput] = useState("");
  const [flow, setFlow] = useState(S.IDLE);
  const [typing, setTyping] = useState(false);
  const [data, setData] = useState({});
  const scrollRef = useRef(null);
  const inputRef = useRef(null);
  const idRef = useRef(1);
  const initialized = useRef(false);

  const scroll = () => setTimeout(() => scrollRef.current?.scrollTo({ top: 99999, behavior: "smooth" }), 60);

  const add = useCallback((role, text, extra = {}) => {
    const id = idRef.current++;
    setMsgs((p) => [...p, { id, role, text, ...extra }]);
    scroll();
  }, []);

  const bot = useCallback((text, extra = {}, ms = 500) => {
    setTyping(true); scroll();
    return new Promise((r) => setTimeout(() => { setTyping(false); add("assistant", text, extra); r(); }, ms));
  }, [add]);

  // Welcome message
  useEffect(() => {
    if (initialized.current) return;
    initialized.current = true;
    setTimeout(() => {
      add("assistant", "Welcome! I'm your student support assistant. I can help you look up your result card, check your marks, or verify your academic records.");
      setTimeout(() => {
        add("assistant", "Just tell me what you need — or try one of the quick actions below.", {
          badge: { type: "info", text: "Type anything to get started" },
        });
      }, 600);
    }, 300);
  }, [add]);

  // ── VERIFICATION ENGINE ──────────────────────────────────────────

  const verify = useCallback(async (state, userText) => {
    const d = { ...data };

    if (state === S.ASK_COLLEGE) {
      d.collegeName = userText.trim();
      setData(d);
      await bot("Looking up your college...", { step: 0 }, 300);
      try {
        const res = await API.verifyCollege(d.collegeName);
        if (res.found) {
          d.collegeId = res.collegeId;
          d.collegeDisplay = res.displayName || d.collegeName;
          setData(d);
          setFlow(S.ASK_ROLL);
          await bot(`College verified: ${d.collegeDisplay}. Now please enter your roll number.`, {
            step: 1, badge: { type: "success", text: "College found" },
          });
        } else {
          setFlow(S.DONE);
          await bot(`I couldn't find "${d.collegeName}" in our records. Please check the spelling or contact your admin for help.`, {
            badge: { type: "error", text: "College not found" },
          });
        }
      } catch {
        setFlow(S.DONE);
        await bot("Something went wrong verifying the college. Please try again later.", { badge: { type: "error", text: "Connection error" } });
      }
    }

    else if (state === S.ASK_ROLL) {
      d.rollNumber = userText.trim();
      setData(d);
      await bot("Checking your roll number...", { step: 1 }, 300);
      try {
        const res = await API.verifyRollNumber(d.rollNumber, d.collegeId);
        if (res.found) {
          d.studentId = res.studentId;
          setData(d);
          setFlow(S.ASK_NAME);
          await bot(`Roll number ${d.rollNumber} found at ${d.collegeDisplay}. One more step — please enter your full name exactly as registered.`, {
            step: 2, badge: { type: "success", text: "Roll number verified" },
          });
        } else {
          setFlow(S.DONE);
          await bot(`Roll number "${d.rollNumber}" was not found under ${d.collegeDisplay}. Double-check your roll number or contact your admin.`, {
            badge: { type: "error", text: "Roll number not found" },
          });
        }
      } catch {
        setFlow(S.DONE);
        await bot("Connection error while verifying your roll number. Please try again.", { badge: { type: "error", text: "Connection error" } });
      }
    }

    else if (state === S.ASK_NAME) {
      d.studentName = userText.trim();
      setData(d);
      await bot("Verifying your identity...", { step: 2 }, 300);
      try {
        const res = await API.verifyName(d.studentName, d.studentId);
        if (res.matched) {
          await bot("Identity verified! Searching for your result card...", {
            badge: { type: "success", text: "Identity confirmed" },
          }, 400);
          try {
            const rc = await API.getResultCard(d.studentId);
            if (rc.found) {
              setFlow(S.DONE);
              await bot("Here is your result card:", {
                resultCard: {
                  studentName: d.studentName,
                  rollNumber: d.rollNumber,
                  collegeName: d.collegeDisplay || d.collegeName,
                  ...rc.resultCard,
                },
              });
            } else {
              await bot("Result card not found. Checking your registration status...", {
                badge: { type: "warning", text: "No result card on file" },
              }, 400);
              try {
                const reg = await API.checkRegistration(d.studentId);
                setFlow(S.DONE);
                if (reg.registered) {
                  await bot("You are registered for exams, but your result card hasn't been uploaded yet. This issue has been flagged — your institution will be notified. Please check back later or contact your exam cell directly.", {
                    badge: { type: "warning", text: "Flagged for review" },
                  });
                } else {
                  await bot("Your exam registration could not be confirmed in our system. Please contact your college admin or exam cell for further assistance.", {
                    badge: { type: "error", text: "Not registered — contact admin" },
                  });
                }
              } catch {
                setFlow(S.DONE);
                await bot("Could not check registration status. Please contact your admin.", { badge: { type: "error", text: "Connection error" } });
              }
            }
          } catch {
            setFlow(S.DONE);
            await bot("Error searching for your result card. Please try again later.", { badge: { type: "error", text: "Connection error" } });
          }
        } else {
          setFlow(S.DONE);
          await bot(`The name "${d.studentName}" doesn't match our records for roll number ${d.rollNumber}. Please make sure you're entering your name exactly as registered, or contact admin.`, {
            badge: { type: "error", text: "Name mismatch" },
          });
        }
      } catch {
        setFlow(S.DONE);
        await bot("Error during name verification. Please try again.", { badge: { type: "error", text: "Connection error" } });
      }
    }
  }, [data, bot]);

  // ── SEND ─────────────────────────────────────────────────────────

  const send = useCallback(async () => {
    const text = input.trim();
    if (!text || typing) return;
    setInput("");
    add("user", text);

    if ([S.ASK_COLLEGE, S.ASK_ROLL, S.ASK_NAME].includes(flow)) {
      await verify(flow, text);
      return;
    }

    if (flow === S.DONE && isResultQuery(text)) {
      setData({});
      setFlow(S.ASK_COLLEGE);
      await bot("Let's look that up. First, please enter your college name.", { step: 0 });
      return;
    }

    if (isResultQuery(text)) {
      setData({});
      setFlow(S.ASK_COLLEGE);
      await bot("I'll help you find that. For security, I need to verify your identity first. Please enter your college name.", { step: 0 });
      return;
    }

    if (text.toLowerCase().includes("hello") || text.toLowerCase().includes("hi")) {
      await bot("Hello! How can I help you today? If you're looking for your result card or marks, just let me know.");
      return;
    }

    if (text.toLowerCase().includes("help")) {
      await bot("I can help you with: looking up your result card, checking your marks and grades, or verifying your student records. Just say something like \"show my result card\" to get started!", {
        badge: { type: "info", text: "Try: \"my result card\"" },
      });
      return;
    }

    await bot("I specialize in student record lookups. If you need your result card, marks, or grades — just ask! For example, try saying \"I want to check my marks\".", {
      badge: { type: "info", text: "Tip: ask about your results" },
    });
  }, [input, typing, flow, add, bot, verify]);

  const onKey = (e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } };

  useEffect(() => { inputRef.current?.focus(); }, []);

  const chips = ["My result card is not found", "Check my marks", "Where is my marksheet?"];

  const placeholders = {
    [S.ASK_COLLEGE]: "Enter your college name...",
    [S.ASK_ROLL]: "Enter your roll number...",
    [S.ASK_NAME]: "Enter your full name as registered...",
  };

  return (
    <div style={{
      display: "flex", flexDirection: "column", height: 640,
      fontFamily: "'Satoshi', 'General Sans', system-ui, sans-serif",
      background: C.bg, borderRadius: 16, overflow: "hidden",
      border: `1px solid ${C.border}`,
      boxShadow: "0 20px 60px rgba(0,0,0,0.4), 0 0 0 1px rgba(108,142,239,0.04)",
    }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap');
        @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700&display=swap');
        * { font-family: 'Outfit', system-ui, sans-serif; box-sizing: border-box; }
        @keyframes msgIn { from { opacity:0; transform:translateY(8px) } to { opacity:1; transform:translateY(0) } }
        @keyframes slideUp { from { opacity:0; transform:translateY(12px) } to { opacity:1; transform:translateY(0) } }
        @keyframes pulse { 0%,100%{opacity:.3;transform:scale(.85)} 50%{opacity:1;transform:scale(1.1)} }
        @keyframes shimmer { 0%{background-position:-200px 0} 100%{background-position:200px 0} }
        ::-webkit-scrollbar { width:5px }
        ::-webkit-scrollbar-track { background:transparent }
        ::-webkit-scrollbar-thumb { background:${C.border};border-radius:8px }
        textarea::placeholder { color:${C.textDim} }
      `}</style>

      {/* ── HEADER ── */}
      <div style={{
        padding: "14px 18px", display: "flex", alignItems: "center", gap: 12,
        borderBottom: `1px solid ${C.border}`,
        background: `linear-gradient(180deg, ${C.surface} 0%, ${C.bg} 100%)`,
      }}>
        <div style={{ position: "relative" }}>
          <div style={{
            width: 38, height: 38, borderRadius: 10,
            background: `linear-gradient(135deg, ${C.accent}, ${C.green})`,
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 16, fontWeight: 800, color: "#fff",
            boxShadow: `0 4px 16px ${C.accent}30`,
          }}>S</div>
          <div style={{
            position: "absolute", bottom: -1, right: -1,
            width: 10, height: 10, borderRadius: "50%",
            background: C.green, border: `2px solid ${C.bg}`,
            boxShadow: `0 0 6px ${C.green}60`,
          }} />
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: C.text, letterSpacing: "-0.01em" }}>
            Student support agent
          </div>
          <div style={{ fontSize: 10, color: C.textDim, letterSpacing: "0.04em", marginTop: 1 }}>
            VERIFICATION &middot; RESULTS &middot; RECORDS
          </div>
        </div>
        <button onClick={() => {
          setMsgs([]);
          setFlow(S.IDLE); setData({}); idRef.current = 1;
          initialized.current = false;
          setTimeout(() => {
            initialized.current = true;
            add("assistant", "Welcome! I'm your student support assistant. I can help you look up your result card, check your marks, or verify your academic records.");
            setTimeout(() => add("assistant", "Just tell me what you need — or try one of the quick actions below.", { badge: { type: "info", text: "Type anything to get started" } }), 600);
          }, 200);
        }} style={{
          background: C.surface2, border: `1px solid ${C.border}`, borderRadius: 8,
          padding: "6px 12px", fontSize: 11, color: C.textDim,
          cursor: "pointer", fontFamily: "inherit", fontWeight: 600,
          transition: "all 0.2s",
        }}
          onMouseEnter={(e) => { e.target.style.borderColor = C.accent; e.target.style.color = C.accent; }}
          onMouseLeave={(e) => { e.target.style.borderColor = C.border; e.target.style.color = C.textDim; }}
        >New chat</button>
      </div>

      {/* ── MESSAGES ── */}
      <div ref={scrollRef} style={{
        flex: 1, overflowY: "auto", padding: "16px 16px 8px",
        display: "flex", flexDirection: "column", gap: 12,
      }}>
        {msgs.map((m) => <Bubble key={m.id} msg={m} />)}

        {typing && (
          <div style={{ display: "flex", gap: 10, alignSelf: "flex-start", animation: "msgIn 0.2s ease" }}>
            <div style={{
              width: 30, height: 30, borderRadius: 8,
              background: `linear-gradient(135deg, ${C.accent}, ${C.green})`,
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 13, fontWeight: 800, color: "#fff",
            }}>S</div>
            <div style={{
              padding: "8px 16px", borderRadius: "14px 14px 14px 4px",
              background: C.surface2, border: `1px solid ${C.border}`,
            }}><Dots /></div>
          </div>
        )}

        {/* Quick action chips */}
        {msgs.length >= 2 && msgs.length < 4 && flow === S.IDLE && (
          <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginTop: 4, animation: "slideUp 0.4s ease" }}>
            {chips.map((c, i) => (
              <button key={i} onClick={() => { setInput(c); setTimeout(() => { inputRef.current?.focus(); }, 50); setTimeout(send, 100); }}
                style={{
                  padding: "7px 14px", borderRadius: 20,
                  border: `1px solid ${C.border}`,
                  background: C.surface2, color: C.textMid,
                  fontSize: 12, cursor: "pointer", fontFamily: "inherit",
                  fontWeight: 500, transition: "all 0.2s",
                }}
                onMouseEnter={(e) => { e.target.style.borderColor = C.accent; e.target.style.color = C.accent; e.target.style.background = C.accentBg; }}
                onMouseLeave={(e) => { e.target.style.borderColor = C.border; e.target.style.color = C.textMid; e.target.style.background = C.surface2; }}
              >{c}</button>
            ))}
          </div>
        )}
      </div>

      {/* ── TEST DATA HINT ── */}
      {flow === S.ASK_COLLEGE && (
        <div style={{
          padding: "0 16px 6px", fontSize: 10, color: C.textDim, lineHeight: 1.5,
          borderTop: `1px solid ${C.border}`, paddingTop: 8, margin: "0 16px",
          fontFamily: "'JetBrains Mono', monospace",
        }}>
          Demo data: Delhi Technical University, Mumbai Institute of Technology, Bangalore Engineering College
        </div>
      )}
      {flow === S.ASK_ROLL && (
        <div style={{
          padding: "0 16px 6px", fontSize: 10, color: C.textDim, lineHeight: 1.5,
          borderTop: `1px solid ${C.border}`, paddingTop: 8, margin: "0 16px",
          fontFamily: "'JetBrains Mono', monospace",
        }}>
          Demo rolls: DTU2024001 (has results), DTU2024003 (no results), MIT2024002 (unregistered)
        </div>
      )}
      {flow === S.ASK_NAME && (
        <div style={{
          padding: "0 16px 6px", fontSize: 10, color: C.textDim, lineHeight: 1.5,
          borderTop: `1px solid ${C.border}`, paddingTop: 8, margin: "0 16px",
          fontFamily: "'JetBrains Mono', monospace",
        }}>
          Demo names: Aarav Sharma, Priya Patel, Rohan Gupta, Sneha Reddy, Arjun Singh, Kavya Nair
        </div>
      )}

      {/* ── INPUT ── */}
      <div style={{
        padding: "10px 14px 14px",
        display: "flex", gap: 8, alignItems: "flex-end",
        background: C.surface,
        borderTop: `1px solid ${C.border}`,
      }}>
        <textarea ref={inputRef} value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={onKey}
          placeholder={placeholders[flow] || "Type a message..."}
          rows={1}
          style={{
            flex: 1, resize: "none", minHeight: 40, maxHeight: 100,
            padding: "10px 14px", fontSize: 13.5, fontFamily: "inherit",
            borderRadius: 10, border: `1px solid ${C.border}`,
            background: C.bg, color: C.text, outline: "none", lineHeight: 1.5,
            transition: "border-color 0.2s",
          }}
          onFocus={(e) => { e.target.style.borderColor = C.accent; e.target.style.boxShadow = `0 0 0 2px ${C.accent}15`; }}
          onBlur={(e) => { e.target.style.borderColor = C.border; e.target.style.boxShadow = "none"; }}
        />
        <button onClick={send} disabled={!input.trim() || typing}
          style={{
            width: 40, height: 40, borderRadius: 10, border: "none",
            background: input.trim() && !typing ? `linear-gradient(135deg, ${C.accent}, ${C.accentDim})` : C.surface2,
            cursor: input.trim() && !typing ? "pointer" : "not-allowed",
            display: "flex", alignItems: "center", justifyContent: "center",
            transition: "all 0.2s", flexShrink: 0,
            boxShadow: input.trim() && !typing ? `0 4px 12px ${C.accent}30` : "none",
          }}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={input.trim() && !typing ? "#fff" : C.textDim} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M22 2L11 13" /><path d="M22 2L15 22L11 13L2 9L22 2Z" />
          </svg>
        </button>
      </div>
    </div>
  );
}
